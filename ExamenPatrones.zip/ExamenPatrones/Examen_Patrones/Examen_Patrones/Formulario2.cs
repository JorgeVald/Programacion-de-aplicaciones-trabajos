﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Examen_Patrones
{
    public partial class Formulario2 : Form
    {
        private static Formulario2 _instancia;
        public static Formulario2 ObtenerInstancia()
        {
            if (_instancia == null || _instancia.IsDisposed)
            {
                _instancia = new Formulario2();
            }
            _instancia.BringToFront();
            return _instancia;
        }
        private Formulario2()
        {
            InitializeComponent();
        }

        private void Formulario2_Load(object sender, EventArgs e)
        {

        }
    }
}
