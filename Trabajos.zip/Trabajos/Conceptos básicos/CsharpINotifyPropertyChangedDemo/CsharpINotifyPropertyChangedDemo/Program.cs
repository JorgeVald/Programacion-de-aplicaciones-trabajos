﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace CsharpINotifyPropertyChangedDemo
{
    /// <summary>
    /// Defines the entry point of the application.
    /// </summary>
    class CsharpINotifyPropertyChangedExample
    {
        static void Main()
        {
            // New instance of the person class
            var person = new Person { FirstName = "A first name", LastName = "A last name" };

            // Show the properties
            Console.WriteLine(person.FirstName);

            Console.WriteLine(person.LastName);

            // Change the properties
            person.FirstName = "changed first name";

            person.LastName = "changed last name";

            // Show the changed properties
            Console.WriteLine(person.FirstName);

            Console.WriteLine(person.LastName);

            Console.ReadKey();
        }
    }

    /// <summary>
    /// Person class implements the INotifyPropertyChanged interface
    /// </summary>
    public class Person : INotifyPropertyChanged
    {
        private string _firstName;

        private string _lastName;

        public string FirstName
        {
            get { return _firstName; }
            set
            {
                _firstName = value;
                OnPropertyChanged(this, "FirstName");
            }
        }

        public string LastName
        {
            get { return _lastName; }
            set
            {
                _lastName = value;
                OnPropertyChanged(this, "LastName");
            }
        }

        // PropertyChanged event
        public event PropertyChangedEventHandler PropertyChanged;

        // Raise the PropertyChanged event
        private void OnPropertyChanged(object sender, string property)
        {
            if (PropertyChanged == null) return;
            PropertyChanged(sender, new PropertyChangedEventArgs(property));
            Console.WriteLine("Changed {0} ", property);
        }
    }
}
