﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace UsandoINotifyPropertyChanged
{
    class estudiante : INotifyPropertyChanged
    {
        private string prop;

        public string nombre
        {
            get
            {
                return nombre;
            }
            set
            {
                if (nombre != value)
                {
                    nombre = value;
                    RaisePropertyChanged("nombre");
                }
            }
        }
        private int grado;
        public int nota
        {
            get
            {
                return nota;
            }
            set
            {
                if (nota != value)
                {
                    nota = value;
                    RaisePropertyChanged("nota");
                }
            }
        }
        public estudiante(string nombre, int grado)
        {
            nombre = nombre;
            nota = nota;
        }
        public void alterarNota()
        {
            nota++;
        }                                                                               
        public event PropertyChangedEventHandler PropertyChanged;
        public void RaisePropertyChanged(string n)
        {
            if (PropertyChanged != null) PropertyChanged (this, new PropertyChangedEventArgs(prop));
        }
    }
}
