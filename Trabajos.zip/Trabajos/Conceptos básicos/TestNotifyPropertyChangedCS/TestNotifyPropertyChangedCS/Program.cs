﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace TestNotifyPropertyChangedCS
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ReadKey();
        }
    }
    public class Persona : INotifyPropertyChanged
    {
        private string nombre;
        public event PropertyChangedEventHandler PropertyChanged;

        public Persona()
        {
        }

        public Persona(string value)
        {
            this.nombre = value;
        }

        public string PersonaNombre
        {
            get { return nombre; }
            set
            {
                nombre = value;
                OnPropertyChanged("PersonaNombre");
            }
        }

        protected void OnPropertyChanged(string nombre)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(nombre));
                Console.ReadKey();
            }
        }
    }
}
