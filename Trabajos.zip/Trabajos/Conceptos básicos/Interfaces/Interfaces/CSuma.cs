﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Interfaces
{
    class CSuma : IOperacion
    {
        //Se tienen que implemntar los métodos de la interfaz 
        private double r = 0;

        private ArrayList resultados = new ArrayList();

        //Métodos a implementar
        public void calcular(double a, double b)
        {
            r = a + b;
        }
        public void mostrar()
        {
            Console.WriteLine("El resultado de la suma es: {0}",r);
            resultados.Add(r);
        }
        //Métodos propios de la clase
        public void muestraResultados()
        {
            foreach (double r in resultados)
                Console.WriteLine(r);
        }

    }
}
