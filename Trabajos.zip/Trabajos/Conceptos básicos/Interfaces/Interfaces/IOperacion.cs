﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaces
{
    interface IOperacion
    {
        //Indicar los prototipos de los métodos
        //¿Qué es lo que tengo que hacer?
        void calcular(double a, double b);
        void mostrar();
    }
}
