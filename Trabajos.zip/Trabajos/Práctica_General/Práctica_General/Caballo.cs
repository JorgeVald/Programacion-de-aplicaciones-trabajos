﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Práctica_General
{
    class Caballo : Mamiferos, IMamiferosTerrestres//se crea la herencia de la clase Mamiferos
                                                   //con la coma (,) se asigna herencia de la interfaz
    {
        private int n = 0;//se asigna una variable para el número de patas del animal
        public Caballo()
        {
        }

        public void galopar()//se crea un método propio del animal, que en este caso es galopar
        {
            Console.WriteLine("El caballo está galopando");//imprime un mensaje
        }
        public void numeroPatas(int num)//se llama el método de la interfaz de numeroPatas
        {
            n = num;//se iguala la variable creada al inicio con el parámetro del método
        }
        public void mostrar()//nos ayuda a mostrar el número de patas
        {
            Console.WriteLine("El número de patas del caballo es: {0}", n);//imprime el número de patas del animal
        }
    }
}
