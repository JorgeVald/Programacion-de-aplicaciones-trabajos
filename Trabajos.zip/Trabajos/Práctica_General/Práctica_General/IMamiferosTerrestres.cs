﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Práctica_General
{
    interface IMamiferosTerrestres
    {
        void numeroPatas(int num);//Este método se crea con un parámetro para ingresar el número de patas del animal
        void mostrar();//Este método nos ayudará a mostrar el número de patas del animal                                                                                             
    }
}
