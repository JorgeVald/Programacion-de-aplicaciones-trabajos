﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Práctica_General
{
    abstract class Animales
    {
        public abstract void getNombre(string nom);//Se crea un método abstracto de Nombre para asignar y obtener el nombre del animal
        public void respirar()//se crea un método no abstracto de Respirar, ya que todos van a respirar
        {
            Console.WriteLine("El animal esta respirando"); //imprime el mensaje que nos da a entender que el animal está respirando
        }
    }
}
