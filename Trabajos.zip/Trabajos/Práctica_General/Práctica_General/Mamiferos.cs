﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Práctica_General
{
    class Mamiferos : Animales//con los dos puntos (:) se hereda de la clase animales
    {
        private string n = "";//se crea una variable de tipo string para ayudarnos a guardar el nombre
        public void cuidarCrias()//se crea un método que será igual para todas las clases hijas, en este caso de cuidar crias
        {
            Console.WriteLine("El animal esta cuidando de sus crías");//imprime un mensaje de que el animal esta cuidando a sus crias
        }
        public void pensar()//se crea un método que será igual para todas las clases hijas, en este caso de pensar
        {
            Console.WriteLine("El animal puede pensar");//imprime un mensaje que nos demuestra que el método funciona
        }
        public override void getNombre(string nom)//se llama el método de nombre de la clase animales
        {                                         //se utiliza override ya que es un método abstracto
            n = nom;//se iguala la variable definida al principio (n) con la variable de parámetro del método heredado
        }
        public void mos()//se crea un método para mostrar el nombre
        {
            Console.WriteLine("El nombre del animal es: {0}", n);//imprime el nombre del animal
        }
    }
}
