﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROXY
{
    class cproxy : ISubject
    {
        Subject subject;
        public string Request()
        {
            if (subject == null)
            {
                subject = new Subject();
            }
            return subject.Request();
        }
    }
}
